// Jeffrey scroggins
//CS 210 class 2021

#include <iostream>
#include <iomanip>
#include <cctype>
#include <stdexcept>
#include <vector>
#include <limits>
#include "bankcalculator.h"


using namespace std;
/*
 * Initial Menu Display. As the user inputs data, next menu item pops up for the user to input data.
 */
int bankcalculator::menuDisplay(){

	cout << setw(33) << setfill('*') << "*" << endl;
	cout << setw(10) << setfill('*') << "*";
	cout << " Data Input ";
	cout << setw(11) << setfill('*') << "*" << endl;
	// Initial investment input
	cout << setw(28) << setfill(' ') << left << "Initial investment amount:";
	InitialInvestment = getMoneyInput();
	cout << "$";
	cout << fixed << setprecision(2) << InitialInvestment << endl;
	//
	// Monthly Deposit input
	cout << setw(28) << setfill(' ') << left << "Monthly deposit:";
	MonthlyDeposit = getMoneyInput();
	cout << "$";
	cout << fixed << setprecision(2) << MonthlyDeposit << endl;
	//
	// Interest Percentage input
	cout << setw(32) << setfill(' ') << left << "Annual interest:";
	Interest = getNumberInput();
	cout << "%" << Interest << endl;
	//
	//Investment Duration input
	cout << setw(32) << setfill(' ') << left << "Number of years:";
	NumYears = getNumberInput();
	cout << NumYears << endl;


	system("pause");
	return 0;

}
void bankcalculator::projectionScreen(){
	/*
	 * Basic display for outputs.
	 */
	cout << "   Balance and Interest with Additional Monthly Deposits" << endl; // 55 chars
	cout << setw(60) << setfill('=') << "=" << endl;
	cout << "Year\t" << "    Year End Balance\t" << "    Year end Earned Interest" << endl; // 45 chars
	InterestCalculations(this->InitialInvestment, this->MonthlyDeposit, this->Interest, this-> NumYears);

	cout << endl;
	cout << endl;

	cout << "   Balance and Interest without Additional Monthly Deposits" << endl; // 58 chars
	cout << setw(60) << setfill('=') << "=" << endl;
	cout << "Year\t" << "    Year End Balance\t" << "    Year end Earned Interest" << endl; // 45 chars
	InterestCalculations(this->InitialInvestment, 0, this->Interest, this-> NumYears);



}
void bankcalculator::InterestCalculations(double InitialInvestment, double MonthlyDeposit, int Interest, int NumYears){
	int i;
	int j;
	int k;

	double newInvestmentAmount = InitialInvestment;
	double interest = Interest;
	double interestTotal= 0;
	const int NUM_MONTHS = 12; // Months in a year
	double compoundInterest;
	vector<double> interests;



	//Variable Pass Checker:



	for(i=1; i<=NumYears; i++){
		for(j=1; j<=NUM_MONTHS; j++){
			newInvestmentAmount = (newInvestmentAmount+MonthlyDeposit);
			compoundInterest = newInvestmentAmount*((interest/100)/NUM_MONTHS);
			newInvestmentAmount = newInvestmentAmount + compoundInterest;
			interests.push_back(compoundInterest);
		}
		// Adds up all interest payments
		for(k=0; k<interests.size(); k++){//vector breakdown
				interestTotal = interests.at(k)+interestTotal;//vector
		}
		/
		//Output text to the user
		cout << i << "\t    $" << newInvestmentAmount << "\t\t     $" << interestTotal << endl;;


		interestTotal = 0;
		compoundInterest = 0;
		interests.resize(0);
	}
}

double bankcalculator::getMoneyInput(){
	double userInput;
	cin >> userInput;

	while(!cin.good() || userInput < 0){
		cout << endl;
		//These statements report on what type of problem were having.
		if(!cin.good()){// if the user is inputting garbage other than numbers...
			cout << "ERROR: We're looking for numbers, not text. Try again: " << endl;
		}
		if(userInput < 0){// if the user is inputting negative numbers.
			cout << "ERROR: We're looking for a positive number here. We don't owe you money for using this! Try again buddy:" << endl;
		}

		//Clean the cin pipe!
		cin.clear();
		cin.ignore(LC_MAX, '\n');

		//Lets try again
		cin >> userInput;

	}
	return userInput;
}
int bankcalculator::getNumberInput(){
	int userInput;
	cin >> userInput;
	/*
	// Error Check:
	// Added this to check for errors
	*/
		while(!cin.good() || userInput < 0){ // In otherwords, if what cin gets is bad OR if userInput is less than zero, enter this loop
			cout << endl;

			if(!cin.good()){// if the user is inputting garbage thats not numbers
				cout << "ERROR: We're looking for numbers, not text. Try again: " << endl;
			}
			if(userInput < 0){// if the user is trying to have a negative interest rate or go backwards in time
				cout << "ERROR: We're looking for a positive number here. Try again: " << endl;
			}

			//Clean the cin pipe!
			cin.clear();
			cin.ignore(LC_MAX, '\n');


			cin >> userInput;
		}
	return userInput;
}
bankcalculator::bankcalculator() {

}
