// Jeffrey scroggins
//CS 210 class 2021
#ifndef bankcalculator_h_
#define bankcalculator_h_

class bankcalculator {
public:
	//Default Constructor
	bankcalculator();
	//Menu options
	int menuDisplay();
	void projectionScreen();

	double getMoneyInput();
	int getNumberInput();
	//Interest earned calculator
	void InterestCalculations(double InitialInvestment, double MonthlyDeposit, int Interest, int NumYears);

private:
	double InitialInvestment;
	double MonthlyDeposit;
	int Interest;
	int NumYears;

};

#endif /* bankcalculator_h_ */
