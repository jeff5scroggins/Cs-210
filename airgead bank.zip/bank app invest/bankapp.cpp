// Jeffrey scroggins
//CS 210 class 2021
#include <iostream>
#include <iomanip>
#include "bankcalculator.h"

using namespace std

int main() {
	//Clean!
	bankcalculator menu;
	menu.menuDisplay();
	menu.projectionScreen();
}
